### Card work flow

- Adds a user dashboard. it will shows the chart diagram of dashboard.