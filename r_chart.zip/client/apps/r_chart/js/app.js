(function() {
    var $dc = $(document);
    var board_response;

    $dc.on('click', '#js-r-card-workflow-app-button', function(event) {
        $('#r_chart_modal').modal('hide');
        return false;
    });

    $dc.ready(function() {
        localforage.getItem('apps', function(err, value) {
            var local_storage_apps = JSON.parse(value);
            $('body').append('<div class="modal fade" id="r_chart_modal" tabindex="-1" role="dialog" aria-labelledby="chartModalLabel" aria-hidden="false"><div class="modal-dialog"><div class="modal-content"><div class="modal-header"><button type="button" class="close" data-dismiss="modal"><span aria-hidden="true" id="js-card-workflow-close">×</span><span class="sr-only">Close</span></button><div class="media list-group-item-heading"><div class="pull-left"><img class="img-circle" width="36" height="36" src="' + local_storage_apps.r_chart.icon + '" /></div><div class="media-body"><h4 class="modal-title" id="exampleModalLabel">' + local_storage_apps.r_chart.name + '</h4><div><span class="text-muted">v' + local_storage_apps.r_chart.version + '</span> By <a target="_blank" href="' + local_storage_apps.r_chart.author_url + '?utm_source=restyaboard&utm_medium=apppopup&utm_campaign=rb-app-card-workflow-v0.1.1' + '" title="author">' + local_storage_apps.r_chart.author + '</a></div></div></div></div><div class="modal-body import-block"><span>' + local_storage_apps.r_chart.description + '</span></div><div class="modal-footer"><a id="js-r-card-workflow-app-button" href="#" title="' + i18next.t('Close') + '" class="btn btn-primary">' + i18next.t('Close') + '</a></div></div></div></div>');
        });

        $('body').bind('DOMSubtreeModified', dashboardChart);

        $('body').bind('DOMSubtreeModified', navigations);
    });

    addResponseCallback(function(xhr) {
        var currenturl = window.location;
        var currentss = currenturl.hash;
        var get_search_url = currentss.split("/");
        if ((!_.isUndefined(currenturl.hash) && (xhr.responseURL.match(/boards\Sjson/g)) && $('.append_dashboard').length === 0) && ((currenturl.hash == '#/boards') || (currenturl.hash == '#/boards/starred') || (currenturl.hash == '#/boards/closed') || ((!_.isUndefined(get_search_url['1']) && (get_search_url['1'] == 'search'))))) {
            board_response = JSON.parse(xhr.response);
        }
    });

    function navigations() {
        var currenturl = window.location;
        var currentss = currenturl.hash;
        var get_search_url = currentss.split("/");
        if (get_search_url['1'] == 'board') {
            boards = App.current_board;
            if (!_.isUndefined(boards) && !_.isEmpty(boards)) {
                _.each(boards.attributes.lists, function(list) {
                    if (!_.isNull(list.name) && !_.isUndefined(list.name) && !_.isEmpty(list.name)) {
                        var list_name = list.name;
                        var list_id = list.id;
                        var strings = '';
                        if (!_.isUndefined(r_chart_todo_color) && !_.isUndefined(r_chart_todo_icon)) {
                            var todo_lists = r_chart_todo.split(", ");
                            _.each(todo_lists, function(todo_list) {
                                if (list_name.trim().toLowerCase() == todo_list.trim().toLowerCase()) {
                                    if ($('.list-added-' + list_id).length === 0) {
                                        strings = '<span><i class="list-added-' + list_id + ' ' + r_chart_todo_icon + '" style="color:' + r_chart_todo_color + '" ></i></span>';
                                        $('.get-name-' + list_id).before(strings);
                                    }
                                }
                            });
                        }
                        if (!_.isUndefined(r_chart_doing_color) && !_.isUndefined(r_chart_doing_icon)) {
                            var doing_lists = r_chart_doing.split(", ");
                            _.each(doing_lists, function(doing_list) {
                                if (list_name.trim().toLowerCase() == doing_list.trim().toLowerCase()) {
                                    if ($('.list-added-' + list_id).length === 0) {
                                        strings = '<span><i class="list-added-' + list_id + ' ' + r_chart_doing_icon + '" style="color:' + r_chart_doing_color + '" ></i></span>';
                                        $('.get-name-' + list_id).before(strings);
                                    }
                                }
                            });
                        }
                        if (!_.isUndefined(r_chart_done_color) && !_.isUndefined(r_chart_done_icon)) {
                            var done_lists = r_chart_done.split(", ");
                            _.each(done_lists, function(done_list) {
                                if (list_name.trim().toLowerCase() == done_list.trim().toLowerCase()) {
                                    if ($('.list-added-' + list_id).length === 0) {
                                        strings = '<span><i class="list-added-' + list_id + ' ' + r_chart_done_icon + '" style="color:' + r_chart_done_color + '" ></i></span>';
                                        $('.get-name-' + list_id).before(strings);
                                    }
                                }
                            });
                        }
                    }
                });
            }
        }
    }


    function dashboardChart() {
        if (!_.isEmpty(authuser.user) && board_response) {
            var data = {};
            var boards = '';
            var profile_picture_path = '';
            if (!_.isEmpty(authuser.user.profile_picture_path) && (!_.isUndefined(authuser.user.profile_picture_path))) {
                var hash = calcMD5(SecuritySalt + 'User' + authuser.user.id + 'png' + 'medium_thumb');
                profile_picture_path = window.location.pathname + 'img/medium_thumb/User/' + authuser.user.id + '.' + hash + '.png';
            }
            data.user_profile_picture = profile_picture_path;
            data.user = authuser.user;
            data.organizations = auth_user_organizations.models;
            if (board_response._metadata && board_response._metadata.dashboard) {
                data.dashboard = board_response._metadata.dashboard;
                var d = new Date();
                var weekday = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];
                var months = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
                var today = weekday[d.getDay()];
                var current_month = months[d.getMonth()];
                var today_count = 0;
                var doing_count = 0;
                var todo_count = 0;
                var done_count = 0;
                var current_week_doing_count = 0;
                var current_week_todo_count = 0;
                var current_week_done_count = 0;
                var overall_doing_count = 0;
                var overall_todo_count = 0;
                var overall_done_count = 0;
                var current_weekwise_doing_count = [0, 0, 0, 0, 0, 0, 0];
                var current_weekwise_todo_count = [0, 0, 0, 0, 0, 0, 0];
                var current_weekwise_done_count = [0, 0, 0, 0, 0, 0, 0];
                var last_weekwise_doing_count = [0, 0, 0, 0, 0, 0, 0];
                var last_weekwise_todo_count = [0, 0, 0, 0, 0, 0, 0];
                var last_weekwise_done_count = [0, 0, 0, 0, 0, 0, 0];
                if (!_.isUndefined(data.dashboard.today)) {
                    doing_count = (data.dashboard.today.DOING) ? (data.dashboard.today.DOING) : 0;
                    todo_count = (data.dashboard.today.TODO) ? (data.dashboard.today.TODO) : 0;
                    done_count = (data.dashboard.today.DONE) ? (data.dashboard.today.DONE) : 0;
                    today_count = parseInt(doing_count) + parseInt(today_count) + parseInt(done_count);
                }
                if (!_.isUndefined(data.dashboard.current_week)) {
                    current_week_doing_count = (data.dashboard.current_week.DOING) ? (data.dashboard.current_week.DOING) : 0;
                    current_week_todo_count = (data.dashboard.current_week.TODO) ? (data.dashboard.current_week.TODO) : 0;
                    current_week_done_count = (data.dashboard.current_week.DONE) ? (data.dashboard.current_week.DONE) : 0;
                }
                if (!_.isUndefined(data.dashboard.overall)) {
                    overall_doing_count = (data.dashboard.overall.DOING) ? (data.dashboard.overall.DOING) : 0;
                    overall_todo_count = (data.dashboard.overall.TODO) ? (data.dashboard.overall.TODO) : 0;
                    overall_done_count = (data.dashboard.overall.DONE) ? (data.dashboard.overall.DONE) : 0;
                }
                if (!_.isUndefined(data.dashboard.current_weekwise)) {
                    current_weekwise_doing_count = (data.dashboard.current_weekwise.DOING) ? (data.dashboard.current_weekwise.DOING) : current_weekwise_doing_count;
                    current_weekwise_todo_count = (data.dashboard.current_weekwise.TODO) ? (data.dashboard.current_weekwise.TODO) : current_weekwise_todo_count;
                    current_weekwise_done_count = (data.dashboard.current_weekwise.DONE) ? (data.dashboard.current_weekwise.DONE) : current_weekwise_done_count;
                }
                if (!_.isUndefined(data.dashboard.last_weekwise)) {
                    last_weekwise_doing_count = (data.dashboard.last_weekwise.DOING) ? (data.dashboard.last_weekwise.DOING) : last_weekwise_doing_count;
                    last_weekwise_todo_count = (data.dashboard.last_weekwise.TODO) ? (data.dashboard.last_weekwise.TODO) : last_weekwise_todo_count;
                    last_weekwise_done_count = (data.dashboard.last_weekwise.DONE) ? (data.dashboard.last_weekwise.DONE) : last_weekwise_done_count;
                }
                var strings = "";
                strings += '<div class="clearfix append_dashboard"><div class="row"><div class="col-md-2 col-sm-12 text-center dashboard-organization"><div class="navbar-btn"><label class="clearfix"><a title="' + data.user.full_name + ' (' + data.user.username + ')" href="#/user/' + data.user.id + '">' + data.user.full_name + ' (' + data.user.username + ')</a></label></div><div class="navbar-btn">';
                if (!_.isEmpty(data.user_profile_picture)) {
                    strings += '<img title="' + data.user.full_name + ' (' + data.user.username + ')" alt="' + data.user.username + '" src="' + data.user_profile_picture + '" width="147" height="145" class="thumbnail center-block">';
                } else {
                    strings += '<i class="avatar avatar-color-194 avatar-lg img-rounded">' + data.user.initials + '</i>';
                }
                strings += '</div><div class="clearfix dropdown navbar-btn"><a href="#" title="Organizations" class="btn btn-primary navbar-btn" data-toggle="dropdown">' + data.organizations.length + '  Organizations <i class="caret"></i> </a><ul class="dropdown-menu arrow dropdown-menu-right text-left">';
                if (!_.isEmpty(data.organizations)) {
                    _.each(data.organizations, function(item, key) {
                        strings += '<li><a href="#/organization/' + item.attributes.id + '" title="' + item.attributes.name + '"> ' + item.attributes.name + '</a></li>';
                    });
                } else {
                    strings += "<li>No Records found</li>";
                }
                if (typeof data.dashboard.unassigned === 'undefined') {
                    data.dashboard.unassigned = 0;
                }
                strings += '</ul></div></div><div class="col-md-10 col-sm-12 clearfix"><div class="col-sm-6 col-md-3 col-xs-12 new-sample-border"><div class="row thumbnail"><div class=" col-md-4 col-xs-4 mauto mob-text-center timer"><h4>' + i18next.t('Today') + '</h4><div class="thumbnail text-center navbar-btn date-schedule dounet-chart-responsive"><div class="sep-bot"> <div class="bg-default h6 text-muted list-group-item-heading">' + current_month + '</div><div class="h3 list-group-item-heading">' + d.getDate() + '</div></div><div>' + today + '</div></div></div><ul class="dashboard-rp-calender list-unstyled chart-block list-group-item-text circle-blk charttopspce dashboard-rp-calender"><li class="list-group-item clearfix no-bor circle-chart"><a class="show"><div id="doughnutChart" class="chart js-chart-dashboard" data-todo="' + todo_count + '" data-doing="' + doing_count + '" data-done="' + done_count + '"></div></a></li></ul><div class="col-xs-12 pull-right navbar-btn"><a href="#" class="btn btn-xs btn-primary pull-right row" data-toggle="dropdown"><i class="caret"></i></a><ul class="dropdown-menu arrow arrow-right js-chart-app-dropdown"><li class="dashboard-search" data-search="today_todo"><a href="#" title="' + i18next.t('Today Todo') + '">' + i18next.t('Today Todo') + '</a></li><li class="dashboard-search" data-search="today_doing"><a href="#" title="' + i18next.t('Today Doing') + '">' + i18next.t('Today Doing') + '</a></li><li class="dashboard-search" data-search="today_done"><a href="#" title="' + i18next.t('Today Done') + '">' + i18next.t('Today Done') + '</a></li></ul></div></div></div><div class="col-md-4 col-sm-6 col-xs-12 new-sample-border mob-no-pad new-sample-border1"><div class="col-xs-12 thumbnail mob-text-center clearfix"><div class=" col-lg-4 col-md-6 col-xs-12 chartbotspce timer"><h4>' + i18next.t('Week') + '</h4><ul class="list-inline week-chart-date navbar-btn datecalendar dounet-calender2"><li class="thumbnail text-center navbar-btn col-xs-4"><div class="sep-bot"><div class="bg-default h6 text-muted list-group-item-heading ">' + data.dashboard.week_start_month + '</div><div class="h3 list-group-item-heading ">' + data.dashboard.week_start_day + '</div></div><div> Mon</div></li><li> to</li><li class="thumbnail text-center navbar-btn col-xs-4"><div class="sep-bot"><div class="bg-default h6 text-muted list-group-item-heading ">' + data.dashboard.week_end_month + '</div><div class="h3 list-group-item-heading ">' + data.dashboard.week_end_day + '</div></div><div> Sun</div></li></ul></div><ul class="list-unstyled chart-block list-group-item-text circle-blk charttopspce dashboard-rp-calender"><li class="list-group-item clearfix no-bor circle-chart"><a class="show"><div id="doughnutChart" class="chart js-chart-dashboard" data-todo="' + current_week_todo_count + '" data-doing="' + current_week_doing_count + '" data-done="' + current_week_done_count + '"></div></a></li></ul><div class="col-xs-12 pull-right navbar-btn"><a href="#" class="btn btn-xs btn-primary pull-right row" data-toggle="dropdown"><i class="caret"></i></a><ul class="dropdown-menu arrow arrow-right js-chart-app-dropdown"><li class="dashboard-search" data-search="week_todo"><a href="#" title="' + i18next.t('Week Todo') + '">' + i18next.t('Week Todo') + '</a></li><li class="dashboard-search" data-search="week_doing"><a href="#" title="' + i18next.t('Week Doing') + '">' + i18next.t('Week Doing') + '</a></li><li class="dashboard-search" data-search="week_done"><a href="#" title="' + i18next.t('Week Done') + '">' + i18next.t('Week Done') + '</a></li></ul></div></div></div><div class=" col-sm-6 col-md-3 col-xs-12 new-sample-border hgt-this-alone"><div class="row thumbnail mob-text-center"><div class="col-lg-4 col-md-6 col-lg-4 col-md-6 col-xs-12 timer"><h4>' + i18next.t('Overall') + '</h4></div><ul class="list-unstyled chart-block list-group-item-text  circle-blk dashboard-rp-calender"><li class="list-group-item clearfix no-bor circle-chart"><a class="show"><div id="doughnutChart" class="chart js-chart-dashboard" data-todo="' + overall_todo_count + '" data-doing="' + overall_doing_count + '" data-done="' + overall_done_count + '"></div></a></li></ul><div class="col-xs-12 pull-right navbar-btn rdbtn"><a href="#" class="btn btn-xs btn-primary pull-right row" data-toggle="dropdown"><i class="caret"></i></a><ul class="dropdown-menu arrow arrow-right js-chart-app-dropdown"><li class="dashboard-search" data-search="overall_todo"><a href="#" title="' + i18next.t('Overall Todo') + '">' + i18next.t('Overall Todo') + '</a></li><li class="dashboard-search" data-search="overall_doing"><a href="#" title="' + i18next.t('Overall Doing') + '">' + i18next.t('Overall Doing') + '</a></li><li class="dashboard-search" data-search="overall_done"><a href="#" title="' + i18next.t('Overall Done') + '">' + i18next.t('Overall Done') + '</a></li></ul></div></div></div><div class=" clearfix col-sm-6 col-md-2 col-xs-12  text-center new-sample-border hgt-this-alone mob-no-pad"><div class="clearfix col-xs-12 thumbnail min-hgt-4res"><h4>' + i18next.t('Unassigned') + '</h4><div class="clearfix h1"><div class="dashboard-search" data-search="unassigned">' + data.dashboard.unassigned + '</div></div><div class="well-sm navbar-btn"></div><div class="well-sm"></div><div class="col-xs-12 pull-right navbar-btn"><a href="#" class="btn btn-xs btn-primary pull-right row" data-toggle="dropdown"><i class="caret"></i></a><ul class="dropdown-menu arrow arrow-right js-chart-app-dropdown"><li class="dashboard-search" data-search="unassigned"><a href="#" title="' + i18next.t('Unassigned') + '">' + i18next.t('Unassigned') + '</a></li></ul></div></div></div><div class="row navbar-btn"><div class="col-sm-6 col-xs-12 navbar-btn"><div class="col-sm-4 h4">This week</div><div class="col-md-8 col-xs-12"><span class="sparklines" data-todo="' + (current_weekwise_todo_count).join() + '" data-doing="' + (current_weekwise_doing_count).join() + '" data-done="' + (current_weekwise_done_count).join() + '" ></span></div></div><div class="col-sm-6 col-xs-12 navbar-btn"><div class="col-sm-4 h4">' + i18next.t('Last week') + '</div><div class="col-md-8 col-xs-12"><span class="sparklines test" data-todo="' + (last_weekwise_todo_count).join() + '" data-doing="' + (last_weekwise_doing_count).join() + '" data-done="' + (last_weekwise_done_count).join() + '" ></span></div></div></div><div class="col-xs-12 text-center navbar-btn"><ul class="list-inline navbar-btn">';
                if (!_.isUndefined(data.user.role_id) && data.user.role_id === "1") {
                    strings += '<li class="navbar-right"><i class="icon-warning-sign text-warning"></i><small class="text-muted"> ' + i18next.t('Todo, Doing, Done are as configured in') + ' <a href="#/apps/r_chart" title="' + i18next.t('settings') + '" class="text-primary"> ' + i18next.t('card workflow settings') + '</a><small></li>';
                }
                strings += '</ul></div></div></div></div>';
                if ($('.append_dashboard').length === 0) {
                    $('.dashboard_checking').before(strings);
                    charts();
                }
            }
        }
    }

    function charts() {
        $('.sparklines').each(function(key) {
            $(this).sparkline($(this).data('todo').split(','), {
                enableTagOptions: true,
                type: 'line',
                fillColor: '#eca186',
                lineColor: '#eca186',
                width: '250',
                height: '25',
                tooltipFormatter: function(sparkline, options, fields) {
                    var curr = new Date();
                    var this_week = (curr.getDate() + 1) - curr.getDay();
                    var selected_day = this_week + fields.offset;
                    if (key === 1) {
                        var last_week = (curr.getDate() - 6) - curr.getDay();
                        selected_day = last_week + fields.offset;
                    }
                    var day = new Date(curr.setDate(selected_day));
                    var current_date = day.toString().split(' ');
                    var today = current_date[0] + ', ' + current_date[1] + ' ' + current_date[2] + ', ' + current_date[3];
                    return "<span>" + today + " <span><br>Todo: " + fields.y;
                }
            });
            $(this).sparkline($(this).data('doing').split(','), {
                composite: true,
                fillColor: '#fee3e0',
                lineColor: '#fee3e0',
                width: '250',
                height: '25',
                tooltipFormatter: function(sparkline, options, fields) {
                    return ",&nbsp;Doing: " + fields.y;
                }
            });
            $(this).sparkline($(this).data('done').split(','), {
                composite: true,
                fillColor: '#65cca9',
                lineColor: '#65cca9',
                width: '250',
                height: '25',
                tooltipFormatter: function(sparkline, options, fields) {
                    return ",&nbsp;Done: " + fields.y;
                }
            });
        });
        $('.js-chart-dashboard').each(function() {
            var data_chart = [];
            $.each($(this).data(), function(index, value) {
                var _data = {};
                _data.title = index.toUpperCase();
                _data.value = parseInt(value);
                if (_data.title == 'TODO') {
                    _data.color = '#eca186';
                } else if (_data.title == 'DOING') {
                    _data.color = '#fee3e0';
                } else if (_data.title == 'DONE') {
                    _data.color = '#65cca9';
                }

                if (parseInt(value) > 0) {
                    data_chart.push(_data);
                }
            });
            $(this).html('').drawDoughnutChart(data_chart);
        });
    }
})();
