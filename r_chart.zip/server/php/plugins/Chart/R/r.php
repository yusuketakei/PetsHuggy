<?php
//todo
function Chart_r_get($passed_values)
{
    global $db_lnk;
    $data = array();
    foreach ($passed_values as $key => $values) {
        $ {
            $key
        } = $values;
    }
    switch ($r_resource_cmd) {
    case '/boards':
        $board_lists = $passed_values['board_lists'];
        $dashboard_response = array();
        $monday = 'last monday';
        $sunday = 'next sunday';
        if (1 == date('N')) {
            $monday = 'today';
        }
        if (0 == date('N')) {
            $sunday = 'today';
        }
        $week_start_day = date('Y-m-d', strtotime($monday));
        $week_end_day = date('Y-m-d', strtotime($sunday));
        $dashboard_response['week_start_day'] = date('d', strtotime($monday));
        $dashboard_response['week_end_day'] = date('d', strtotime($sunday));
        $dashboard_response['week_start_month'] = date('M', strtotime($monday));
        $dashboard_response['week_end_month'] = date('M', strtotime($sunday));
        if (!empty($board_lists) && $r_resource_cmd == '/boards' && (!empty($r_resource_filters['type']) && $r_resource_filters['type'] == 'simple')) {
            $settings = array();
            $json = file_get_contents(APP_PATH . '/client/apps/r_chart/app.json');
            $json_data = json_decode($json, true);
            $settings['TODO'] = explode(',', strtolower($json_data['settings']['r_chart_todo']['value']));
            $settings['DOING'] = explode(',', strtolower($json_data['settings']['r_chart_doing']['value']));
            $settings['DONE'] = explode(',', strtolower($json_data['settings']['r_chart_done']['value']));
            if (!empty($settings)) {
                $settings_lists = array();
                $my_lists = array();
                foreach ($board_lists as $list) {
                    foreach ($settings as $key => $setting) {
                        $trim = trim($list['name']);
                        $str_low = strtolower($trim);
                        if (in_array($str_low, array_map('trim', $setting))) {
                            $my_lists[] = $list['id'];
                            $settings_lists[$key][] = $list['id'];
                        }
                    }
                }
                $user_con = ($authUser['role_id'] == 1) ? '' : 'cu.user_id = ' . $authUser['id'] . ' and ';
                foreach ($settings_lists as $key => $settings_list) {
                    $s_sql = pg_query_params($db_lnk, 'SELECT count(cl.id) as cnt FROM cards_listing cl left join cards_users cu on cu.card_id = cl.id where ' . $user_con . 'CAST(cl.due_date AS DATE) = current_date::date and cl.list_id IN (' . implode($settings_list, ',') . ')', array());
                    while ($row = pg_fetch_assoc($s_sql)) {
                        $dashboard_response['today'][$key] = $row['cnt'];
                    }
                    $s_sql = pg_query_params($db_lnk, 'SELECT count(cl.id) as cnt FROM cards_listing cl left join cards_users cu on cu.card_id = cl.id where ' . $user_con . 'cl.list_id IN (' . implode($settings_list, ',') . ')', array());
                    while ($row = pg_fetch_assoc($s_sql)) {
                        $dashboard_response['overall'][$key] = $row['cnt'];
                    }
                    $s_sql = pg_query_params($db_lnk, 'SELECT count(cl.id) as cnt FROM cards_listing cl left join cards_users cu on cu.card_id = cl.id where ' . $user_con . 'CAST(cl.due_date AS DATE) between \'' . $week_start_day . '\' and \'' . $week_end_day . '\' and cl.list_id IN (' . implode($settings_list, ',') . ')', array());
                    while ($row = pg_fetch_assoc($s_sql)) {
                        $dashboard_response['current_week'][$key] = $row['cnt'];
                    }
                    $s_sql = pg_query_params($db_lnk, 'select (SELECT count(cl.id) as cnt FROM cards_listing cl left join cards_users cu on cu.card_id = cl.id where ' . $user_con . '(CAST(due_date AS DATE) =  cast(date_trunc(\'week\', current_date) as date) + i) and cl.list_id IN (' . implode($settings_list, ',') . ')) from generate_series(0,6) i', array());
                    while ($row = pg_fetch_assoc($s_sql)) {
                        $dashboard_response['current_weekwise'][$key][] = $row['cnt'];
                    }
                    $s_sql = pg_query_params($db_lnk, 'select (SELECT count(cl.id) as cnt FROM cards_listing cl left join cards_users cu on cu.card_id = cl.id where ' . $user_con . '(CAST(due_date AS DATE) =  cast(date_trunc(\'week\', current_date - interval \'7 days\') as date) + i) and cl.list_id IN (' . implode($settings_list, ',') . ')) from generate_series(0,6) i', array());
                    while ($row = pg_fetch_assoc($s_sql)) {
                        $dashboard_response['last_weekwise'][$key][] = $row['cnt'];
                    }
                }
                if (!empty($my_lists)) {
                    $s_sql = pg_query_params($db_lnk, 'SELECT count(id) as cnt FROM cards_listing where cards_user_count = 0 and list_id IN (' . implode($my_lists, ',') . ')', array());
                    while ($row = pg_fetch_assoc($s_sql)) {
                        $dashboard_response['unassigned'] = $row['cnt'];
                    }
                }
                $data['_metadata']['dashboard'] = $dashboard_response;
            }
        } else {
            $data['_metadata']['dashboard'] = $dashboard_response;
        }
        break;
    }
    $return_plugin['response'] = $data;
    return $return_plugin;
}
