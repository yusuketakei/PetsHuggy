### APPs

1. Upload the zip and extract in installed Restyaboard path (e.g., /usr/share/nginx/html/restyaboard).
2. To configure apps - http://your_domain.com/#/apps/apps_name
3. App configuration completed